#include "mbed.h"
#include "RF24.h"

//const uint64_t  SLAVE_ADDRESS = 0xE7E7E7E700;//0xF0F0F0F0F0F0F001L;    // slave's address
const uint64_t  ADDRESS = 0xE7E7E7E700;

Serial pc(USBTX, USBRX);
DigitalOut      led(LED1);                              // LED1
RF24            radio(A6,A5,A4,A3,D3);    // mosi, miso, sck, csn, ce, (irq not used)
uint8_t         payload;
bool            role=0;
bool            radionumber = 1; // 303
int main()
{
    uint8_t temp = 0; // 00: 0 , 01: 1
    // Initialize nRF24L01
    if (!radio.begin()) {
        printf("Failed to initialize nRF24L01. Check whether connected.\r\n");
        return -1;  // Exit the program
    }
    radio.setPALevel(RF24_PA_LOW);
    radio.setRetries(5, 15);
    radio.setPayloadSize(sizeof(payload));
    radio.setAutoAck(true);
    radio.setChannel(100);
    if (radionumber)
    {
        radio.openWritingPipe(ADDRESS);
        radio.openReadingPipe(0, ADDRESS);  // use pipe 0 of this slave to receive messsages and send back auto acknowledge
        }
    else
    {
        radio.openWritingPipe(ADDRESS);
        radio.openReadingPipe(0, ADDRESS);  // use pipe 0 of this slave to receive messsages and send back auto acknowledge
        }
    radio.startListening();
    while (1) {
        if (role==1)
        {
        // Send led's status to slave
        radio.stopListening();
        //radio.openWritingPipe(SLAVE_ADDRESS2);
        if (radio.write(&payload, sizeof(payload))) // send message to slave and get acknowledge
            printf("Message delivery succeeded.\r\n");
        else
            printf("Message delivery failed.\r\n");
        radio.startListening();
        }
        //wait(1);
        if(role == 0)
        {
        // read message

         if (radio.available())
          {
            radio.read(&payload, sizeof(payload)); // read message and send acknowledge back to the master
            radio.stopListening();
            radio.write(&payload, sizeof(payload));
            radio.startListening();
            
            printf("recieved: %d\n\r",temp);
          }
        }
        
        if(pc.readable())
        {
            char c = pc.getc();
            printf("%c\n\r",c);
            if(c == '0')//(c == 'R') && (role == 0)
            {
                printf("RX mode\n\r");
                role = 0;
            }
                else if(c == '1')//(c == 'T') && (role == 1)
                {
                    printf("TX mode\n\r");
                    role = 1;
                    radio.startListening();
                }
            }
    }
}
